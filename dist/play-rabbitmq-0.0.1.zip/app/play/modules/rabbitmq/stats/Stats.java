package play.modules.rabbitmq.stats;

import java.io.*;

public class Stats implements Serializable {

	private long consumerSuccessCount;
	
	private long consumerFailedCount;
	
	private long consumerTotalCount;
	
	private long producerSuccessCount;
	
	private long producerFailedCount;
	
	private long producerTotalCount;

}

