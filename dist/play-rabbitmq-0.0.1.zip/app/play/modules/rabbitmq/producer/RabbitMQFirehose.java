package play.modules.rabbitmq.producer;

import org.apache.commons.lang.StringUtils;

import play.Logger;
import play.cache.Cache;
import play.modules.rabbitmq.util.ExceptionUtil;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

import play.Logger;
import play.Play;
import play.jobs.Job;
import play.modules.rabbitmq.RabbitMQPlugin;
import play.modules.rabbitmq.util.ExceptionUtil;

import com.rabbitmq.client.AMQP.Queue;
import com.rabbitmq.client.Channel;
import com.rabbitmq.client.Connection;
import com.rabbitmq.client.QueueingConsumer;

public abstract class RabbitMQFirehose extends Job {
	
	public void doJob() {
		while ( true ) {
			try {
				int itemsCount = 0;
				List<String> items = getData(batchSize());
				if ( items != null && items.size() > 0 ) {
					itemsCount = items.size();
					for ( String item : items ) {
						try {
						RabbitMQPublisher.publishMessage(queueName(), item);
						} catch (Throwable t) {
							Logger.error(ExceptionUtil.getStackTrace(t));
						}
					}
				}
				if ( itemsCount < batchSize() ) {
					Thread.sleep(sleepInBetweenBatches());
				}
				
			
			} catch (Throwable t) {
				Logger.error(ExceptionUtil.getStackTrace(t));
			}
		}
	}
	
	protected abstract List<String> getData(int n);
	
	protected abstract int batchSize();
	
	protected abstract String queueName();
	
	protected long sleepInBetweenBatches() {
		long l = 1000l; // 1 sec
		l = l * 60; // 1 minute
		l = l * 5; // 5 minutes
		return l;
	}

}
